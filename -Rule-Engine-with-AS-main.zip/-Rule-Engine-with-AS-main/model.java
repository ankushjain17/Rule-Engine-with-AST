package com.yourname.ruleengine;

public class model {
}
