# -Rule-Engine-with-AS
Develop a simple 3-tier rule engine application(Simple UI, API and Backend, Data) to determine  user eligibility based on attributes like age, department, income, spend etc.The system can use  Abstract Syntax Tree (AST) to represent conditional rules and allow for dynamic  creation,combination, and modification of these rules.
